import React, { useState } from 'react';
import { View, User } from '../types';

interface HeaderProps {
  user: User | null;
  cartCount: number;
  onNavigate: (view: View) => void;
  onLogout: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onShowHelp: () => void;
  // 接收外部傳入的搜尋執行函式
  onSearch: (q: string) => void;
}

const Header: React.FC<HeaderProps> = ({ user, cartCount, onNavigate, onLogout, searchQuery, setSearchQuery, onShowHelp, onSearch }) => {
  const [isListening, setIsListening] = useState(false);

  // 處理 Enter 鍵搜尋
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      onSearch(searchQuery);
    }
  };

  // 語音輸入 (使用瀏覽器原生 Web Speech API，免費)
  const handleVoiceSearch = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('您的瀏覽器不支援語音輸入，請使用 Chrome 或 Edge。');
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.lang = 'zh-TW';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setSearchQuery(transcript);
      // 語音辨識完直接搜尋
      onSearch(transcript);
    };

    recognition.start();
  };

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-r from-[#EE4D2D] to-[#FF7337] shadow-lg">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between gap-8">
        
        {/* Logo */}
        <div 
          onClick={() => {
             // 點擊 Logo 回首頁並清空搜尋
             setSearchQuery('');
             onSearch(''); // 觸發空搜尋以重置商品列表
             onNavigate(View.SHOP);
          }}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="bg-white rounded-full p-0.5 shadow-sm group-hover:scale-105 transition-transform overflow-hidden">
             <img 
               src="/logo-new.png" 
               alt="InsBuy Logo" 
               className="h-12 w-12 object-cover rounded-full" 
             />
          </div>
          <span className="text-2xl font-black text-white tracking-tight drop-shadow-sm hidden md:block">
            InsBuy
          </span>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-2xl hidden md:block relative">
          <input 
            type="text" 
            placeholder={isListening ? "正在聆聽..." : "搜尋商品、賣家或品牌..."}
            className={`w-full bg-white border-0 rounded-full py-2.5 px-6 pl-6 pr-16 focus:outline-none focus:ring-2 focus:ring-orange-300 text-slate-800 shadow-sm placeholder:text-slate-400 ${isListening ? 'ring-2 ring-red-400 animate-pulse' : ''}`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            // 綁定鍵盤事件
            onKeyDown={handleKeyDown}
          />
          
          <div className="absolute right-1.5 top-1.5 bottom-1.5 flex items-center gap-1">
             {/* 語音按鈕 */}
             <button 
               onClick={handleVoiceSearch}
               className={`w-8 h-8 rounded-full text-slate-400 hover:text-[#EE4D2D] hover:bg-slate-100 transition flex items-center justify-center ${isListening ? 'text-red-500 bg-red-50' : ''}`}
               title="語音搜尋"
             >
               <i className={`fa-solid ${isListening ? 'fa-microphone-lines animate-bounce' : 'fa-microphone'}`}></i>
             </button>

             {/* 搜尋按鈕 */}
             <button 
                onClick={() => onSearch(searchQuery)}
                className="bg-gradient-to-r from-[#EE4D2D] to-[#FF7337] text-white w-10 h-full rounded-full hover:opacity-90 transition-opacity flex items-center justify-center shadow-md ml-1"
             >
                <i className="fa-solid fa-magnifying-glass"></i>
             </button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onShowHelp}
            className="w-10 h-10 rounded-full hover:bg-white/20 flex items-center justify-center text-white transition"
            title="幫助中心"
          >
            <i className="fa-regular fa-circle-question text-xl"></i>
          </button>

          <button 
            onClick={() => onNavigate(View.CART)}
            className="w-10 h-10 rounded-full hover:bg-white/20 flex items-center justify-center text-white transition relative"
          >
            <i className="fa-solid fa-cart-shopping text-xl"></i>
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 w-5 h-5 bg-white text-[#EE4D2D] text-[10px] font-bold rounded-full flex items-center justify-center border border-white shadow-sm">
                {cartCount}
              </span>
            )}
          </button>

          {user ? (
            <div className="flex items-center gap-3 pl-4 border-l border-white/30">
              {user.role === 'ADMIN' && (
                <button 
                  onClick={() => onNavigate(View.ADMIN_HOME)}
                  className="hidden md:flex items-center gap-2 px-4 py-2 bg-white/20 text-white text-xs font-bold rounded-full shadow hover:bg-white/30 transition mr-2 backdrop-blur-sm"
                >
                  <i className="fa-solid fa-gauge-high"></i>
                  管理後台
                </button>
              )}

              <div 
                onClick={() => user.role === 'BUYER' ? onNavigate(View.BUYER_DASHBOARD) : onNavigate(View.ADMIN_HOME)}
                className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition"
              >
                <div className="w-9 h-9 rounded-full bg-white border-2 border-white/50 overflow-hidden">
                  {user.logo ? <img src={user.logo} alt="avatar" className="w-full h-full object-cover" /> : (
                    <div className="w-full h-full flex items-center justify-center bg-slate-200 text-slate-600 font-bold">
                      {user.name[0]}
                    </div>
                  )}
                </div>
                <div className="hidden lg:block text-sm">
                  <p className="font-bold text-white leading-tight">{user.name}</p>
                  <p className="text-[10px] text-white/80 font-medium">{user.role}</p>
                </div>
              </div>
              <button 
                onClick={onLogout}
                className="w-9 h-9 rounded-full hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition"
                title="登出"
              >
                <i className="fa-solid fa-arrow-right-from-bracket"></i>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 pl-4 border-l border-white/30">
              <button 
                onClick={() => onNavigate(View.AUTH)}
                className="px-5 py-2 text-sm font-bold text-white hover:opacity-80 transition flex items-center gap-2 border border-white/40 rounded-full bg-white/10"
              >
                <i className="fa-regular fa-user"></i>
                登入
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;